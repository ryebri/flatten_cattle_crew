var classapp_1_1_sensor_data =
[
    [ "SensorData", "classapp_1_1_sensor_data.html#aa57d3a5ae661a54a78ef9cc0fe994a6b", null ],
    [ "add_data", "classapp_1_1_sensor_data.html#a1eb2ee55945d2a4490c7a6a49532197e", null ],
    [ "get_obstr_size", "classapp_1_1_sensor_data.html#ad3a703471cf231a7772e037c27a05072", null ],
    [ "get_position", "classapp_1_1_sensor_data.html#a33241e2a70c2f729e1762032b78d4400", null ],
    [ "getData", "classapp_1_1_sensor_data.html#add2459c1e1ddd3705735b208fc934aad", null ],
    [ "getName", "classapp_1_1_sensor_data.html#a78ee178b6a73658d65ca60da4d1e6683", null ],
    [ "getObstruction", "classapp_1_1_sensor_data.html#a006659cbde2730f8edd0b609d495ce11", null ],
    [ "getSensors", "classapp_1_1_sensor_data.html#a09ad2961f1c98b02cec840214fee62dc", null ],
    [ "flag_data_done", "classapp_1_1_sensor_data.html#aa4a65787000cb8061879ffffe725b8d4", null ]
];