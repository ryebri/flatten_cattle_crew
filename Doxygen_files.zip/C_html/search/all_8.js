var searchData=
[
  ['object_5fsend',['object_send',['../main_8c.html#a3348bfe23441ee3007d35f3202a02308',1,'main.c']]],
  ['objects',['Objects',['../struct_objects.html',1,'']]],
  ['oi_5ft',['oi_t',['../structoi__t.html',1,'']]]
];
