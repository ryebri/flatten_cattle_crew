var searchData=
[
  ['update_5fpositions',['update_positions',['../classapp_1_1_position.html#a5e863f1a30a4acb8184eeba2dce29a79',1,'app.Position.update_positions(int x, int x_negative, int y, int y_negative, int orientation, int status)'],['../classapp_1_1_position.html#ad54ffb2206e8e5198b940b34de1e421e',1,'app.Position.update_positions(int[] pos)']]]
];
