var searchData=
[
  ['get_5fdistance',['get_distance',['../botdata_8c.html#a64dbe65f3ea363df7ddbdbb2cbabcd4b',1,'get_distance():&#160;botdata.c'],['../main_8c.html#a64dbe65f3ea363df7ddbdbb2cbabcd4b',1,'get_distance():&#160;botdata.c']]],
  ['getadc',['getADC',['../botdata_8c.html#a8d577da9db3345495d3bf210b0520b39',1,'getADC():&#160;botdata.c'],['../main_8c.html#a8d577da9db3345495d3bf210b0520b39',1,'getADC():&#160;botdata.c']]],
  ['getto',['getTo',['../botlogic_8c.html#a71f2cf2c745fbd30fe829d00b7628b27',1,'botlogic.c']]]
];
