var searchData=
[
  ['mainapp',['MainApp',['../classapp_1_1_main_app.html',1,'app']]],
  ['mainpagecontroller',['MainPageController',['../classapp_1_1view_1_1_main_page_controller.html',1,'app::view']]]
];
