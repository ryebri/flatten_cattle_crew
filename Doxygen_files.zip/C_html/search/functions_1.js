var searchData=
[
  ['botdata_5finit',['botdata_init',['../botdata_8c.html#a4ed1d1ad5a6cce60823e8220317b32bc',1,'botdata.c']]],
  ['botpos_5finit',['botpos_init',['../movement_8c.html#ae7ccaac0a9015cedb409acb701b3dcf7',1,'movement.c']]]
];
