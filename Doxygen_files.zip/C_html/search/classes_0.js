var searchData=
[
  ['botdata',['botdata',['../structbotdata.html',1,'']]],
  ['botpos',['botpos',['../structbotpos.html',1,'']]]
];
