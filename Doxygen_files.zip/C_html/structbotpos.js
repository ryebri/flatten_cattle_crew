var structbotpos =
[
    [ "angle", "structbotpos.html#a63177970cacb40efba67ce501ea89210", null ],
    [ "bump", "structbotpos.html#ae154ebaf3202017919762ba4b84c2cbc", null ],
    [ "forward", "structbotpos.html#aa8a182241e9a8f435392df822e890686", null ],
    [ "right", "structbotpos.html#a2f54f8b71f0d765e2b7dbd9a8b9774ff", null ],
    [ "sensor_data", "structbotpos.html#af6a01788aeb90b568a250367fb806cc6", null ]
];