var botlogic_8c =
[
    [ "avoid", "botlogic_8c.html#a15c89ef6632a3da763dc61ecf98a61b3", null ],
    [ "getTo", "botlogic_8c.html#a71f2cf2c745fbd30fe829d00b7628b27", null ],
    [ "play_song", "botlogic_8c.html#a421afe0c4d832ad08bc00f54aaa3a173", null ],
    [ "send_sensor", "botlogic_8c.html#a36c2a42ff40b0936a7244ae097df0fa9", null ]
];