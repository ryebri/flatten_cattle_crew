var classapp_1_1_obstruction =
[
    [ "ObstructionType", "enumapp_1_1_obstruction_1_1_obstruction_type.html", "enumapp_1_1_obstruction_1_1_obstruction_type" ],
    [ "Obstruction", "classapp_1_1_obstruction.html#aa322574c048aa36c81e5a6e81f920415", null ],
    [ "Obstruction", "classapp_1_1_obstruction.html#a13ee59ffe1388964658aa8ff55b2173e", null ],
    [ "drawShape", "classapp_1_1_obstruction.html#ad04da2ff5053b94052f1019fbe89de3f", null ],
    [ "get_angle", "classapp_1_1_obstruction.html#a7f649fec4f96d95eaa6e45869d8c7a87", null ],
    [ "get_distance", "classapp_1_1_obstruction.html#a493f5038e9e4474472e576a38ab4d068", null ],
    [ "get_type", "classapp_1_1_obstruction.html#aeefd79ede8ef57ab298096b3335f67aa", null ],
    [ "get_width", "classapp_1_1_obstruction.html#a3190e4645454cb66c939eadd3dbad84a", null ],
    [ "set_angle", "classapp_1_1_obstruction.html#a06e6f77dec5680e7438791882bd512ea", null ],
    [ "set_distance", "classapp_1_1_obstruction.html#a21795ce416bd5002b162e525d2cd9eb4", null ],
    [ "set_type", "classapp_1_1_obstruction.html#ab5211837394af2896427cc45fabab2a7", null ],
    [ "set_width", "classapp_1_1_obstruction.html#a595ce528012151b33f7bf54ba1b30d26", null ]
];