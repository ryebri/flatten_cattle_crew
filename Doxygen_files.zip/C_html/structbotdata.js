var structbotdata =
[
    [ "commands", "structbotdata.html#a7b4b846f0c18506d7a620cfc6670afa3", null ],
    [ "edges", "structbotdata.html#aaf4459db2c135233a71946f33154e1a2", null ],
    [ "ir_measure", "structbotdata.html#a84df898530711ab289926350f51a0f77", null ],
    [ "ir_measure_raw", "structbotdata.html#a896cafef076ae85a4b1c6bd021cf1bde", null ],
    [ "obj", "structbotdata.html#a09eac5163d61de313b18295fd67e9a45", null ],
    [ "obj_count", "structbotdata.html#af54bf65a3b1679f732ef53816aa0d523", null ],
    [ "skip", "structbotdata.html#aaffdbf12e841f154c83cf25a3f402079", null ]
];