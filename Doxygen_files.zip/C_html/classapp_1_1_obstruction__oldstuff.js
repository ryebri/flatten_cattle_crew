var classapp_1_1_obstruction__oldstuff =
[
    [ "ObstructionType", "enumapp_1_1_obstruction__oldstuff_1_1_obstruction_type.html", "enumapp_1_1_obstruction__oldstuff_1_1_obstruction_type" ],
    [ "Obstruction_oldstuff", "classapp_1_1_obstruction__oldstuff.html#a8dabfd4620fdcded227b0ad2ee1e38aa", null ],
    [ "Obstruction_oldstuff", "classapp_1_1_obstruction__oldstuff.html#a38b065f24fea7f108dc7368119eb785e", null ],
    [ "get_angle", "classapp_1_1_obstruction__oldstuff.html#a7f649fec4f96d95eaa6e45869d8c7a87", null ],
    [ "get_distance", "classapp_1_1_obstruction__oldstuff.html#a64dbe65f3ea363df7ddbdbb2cbabcd4b", null ],
    [ "get_point", "classapp_1_1_obstruction__oldstuff.html#aa6227d58878619377d9b912563b7d564", null ],
    [ "get_type", "classapp_1_1_obstruction__oldstuff.html#aeefd79ede8ef57ab298096b3335f67aa", null ],
    [ "get_width", "classapp_1_1_obstruction__oldstuff.html#a3190e4645454cb66c939eadd3dbad84a", null ],
    [ "set_angle", "classapp_1_1_obstruction__oldstuff.html#a06e6f77dec5680e7438791882bd512ea", null ],
    [ "set_distance", "classapp_1_1_obstruction__oldstuff.html#a1eba0f736946e3a9933a3a60cb03ba24", null ],
    [ "set_point", "classapp_1_1_obstruction__oldstuff.html#a1e0f40406bbe8de15235d5ceecfdb2fe", null ],
    [ "set_type", "classapp_1_1_obstruction__oldstuff.html#ab5211837394af2896427cc45fabab2a7", null ],
    [ "set_width", "classapp_1_1_obstruction__oldstuff.html#a595ce528012151b33f7bf54ba1b30d26", null ]
];