var classapp_1_1view_1_1_output_text_controller =
[
    [ "Colors", "enumapp_1_1view_1_1_output_text_controller_1_1_colors.html", "enumapp_1_1view_1_1_output_text_controller_1_1_colors" ],
    [ "OutputTextController", "classapp_1_1view_1_1_output_text_controller.html#aa03f2f062ae33ea4900f6970e6ba1e3b", null ],
    [ "onEnter", "classapp_1_1view_1_1_output_text_controller.html#aaa7510f1932e65fcd0bd1a04f807d408", null ],
    [ "print_string", "classapp_1_1view_1_1_output_text_controller.html#a1227c575c49f64ef4a02cbd383e0e6af", null ],
    [ "receive_all", "classapp_1_1view_1_1_output_text_controller.html#ae886b317e5ef73a7d1fee7cd99ca0c6a", null ],
    [ "receive_position", "classapp_1_1view_1_1_output_text_controller.html#a2c5a758009222ac00fc974f4c272b164", null ],
    [ "set_sensor", "classapp_1_1view_1_1_output_text_controller.html#a338465ab551ec67e9f526604853a6e25", null ],
    [ "setMainApp", "classapp_1_1view_1_1_output_text_controller.html#abff3a2332fc5333fdbaff0105b9ef004", null ]
];