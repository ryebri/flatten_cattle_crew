var enumapp_1_1_obstruction_1_1_obstruction_type =
[
    [ "ObstructionType", "enumapp_1_1_obstruction_1_1_obstruction_type.html#a0cfe12353e11c60432c4fed7d239b2e0", null ],
    [ "getValue", "enumapp_1_1_obstruction_1_1_obstruction_type.html#aae714dc01fe7f5bb1a175d0d1068bb92", null ],
    [ "HOLE", "enumapp_1_1_obstruction_1_1_obstruction_type.html#a825cac2ef29a70a44cb153a87716e775", null ],
    [ "LARGE_PIPE", "enumapp_1_1_obstruction_1_1_obstruction_type.html#a44196d4949f42eb7fd0e88b1fe5ec49d", null ],
    [ "LINE", "enumapp_1_1_obstruction_1_1_obstruction_type.html#a6b5b06de3f4a6ecf7e536a72f2b39c4d", null ],
    [ "ROCK", "enumapp_1_1_obstruction_1_1_obstruction_type.html#a41c89d07e31766c7e8eff6c35f6d83a9", null ],
    [ "SMALL_PIPE", "enumapp_1_1_obstruction_1_1_obstruction_type.html#ac5bcc5b42a6b4944832c4965a2f6b194", null ]
];