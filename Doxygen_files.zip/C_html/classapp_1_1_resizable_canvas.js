var classapp_1_1_resizable_canvas =
[
    [ "ResizableCanvas", "classapp_1_1_resizable_canvas.html#afd7fb75289157a1e2f52789790df34f9", null ],
    [ "isResizable", "classapp_1_1_resizable_canvas.html#aaa191d255fed4b33b0f3fa6ac8778393", null ],
    [ "prefHeight", "classapp_1_1_resizable_canvas.html#a22861544e857c58593c163f683eac7b8", null ],
    [ "prefWidth", "classapp_1_1_resizable_canvas.html#a6f83c884a4cd4db236c322dee19f7597", null ]
];