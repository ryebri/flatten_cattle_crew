var classapp_1_1xboxcontrollerinterface =
[
    [ "xboxcontrollerinterface", "classapp_1_1xboxcontrollerinterface.html#a1403ba374b0dac6a2af5902752d40032", null ],
    [ "set_roomba_control", "classapp_1_1xboxcontrollerinterface.html#a81a3aaa5cdf3d486f225374c1c7235aa", null ]
];