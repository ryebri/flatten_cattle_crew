var struct_objects =
[
    [ "distance", "struct_objects.html#afb9412686cd344ad61757c1c19ba8a87", null ],
    [ "end_degree", "struct_objects.html#a83a97b2e235b7e1a5eaefab017e3f566", null ],
    [ "number", "struct_objects.html#a7106e2abc437ad981830d14176d15f09", null ],
    [ "start_degree", "struct_objects.html#a544f3f9f6f89a1b34e628d4504371ec0", null ],
    [ "width", "struct_objects.html#a2474a5474cbff19523a51eb1de01cda4", null ]
];