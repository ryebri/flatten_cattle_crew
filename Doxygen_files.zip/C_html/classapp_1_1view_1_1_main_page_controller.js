var classapp_1_1view_1_1_main_page_controller =
[
    [ "MainPageController", "classapp_1_1view_1_1_main_page_controller.html#ad4aa0dead54234b004a84e408d49ac14", null ]
];