var annotated_dup =
[
    [ "botdata", "structbotdata.html", "structbotdata" ],
    [ "botpos", "structbotpos.html", "structbotpos" ],
    [ "Objects", "struct_objects.html", "struct_objects" ],
    [ "oi_t", "structoi__t.html", "structoi__t" ]
];