var searchData=
[
  ['initrootlayout',['initRootLayout',['../classapp_1_1_main_app.html#a2b1a274f6571f1452d352a98acae467f',1,'app::MainApp']]]
];
