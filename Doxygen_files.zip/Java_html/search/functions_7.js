var searchData=
[
  ['main',['main',['../classapp_1_1_main_app.html#a8b260eecbaabcef8473fd87ada040682',1,'app::MainApp']]],
  ['mainapp',['MainApp',['../classapp_1_1_main_app.html#ab97ff91997b508778da8abd719c0afea',1,'app::MainApp']]]
];
