var searchData=
[
  ['add_5fdata',['add_data',['../classapp_1_1_sensor_data.html#a1eb2ee55945d2a4490c7a6a49532197e',1,'app::SensorData']]]
];
