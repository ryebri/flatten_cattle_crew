var dir_22870382958aa4375bc3a401054c5cea =
[
    [ "MainPageController.java", "_main_page_controller_8java.html", [
      [ "MainPageController", "classapp_1_1view_1_1_main_page_controller.html", "classapp_1_1view_1_1_main_page_controller" ]
    ] ],
    [ "OutputTextController.java", "_output_text_controller_8java.html", [
      [ "OutputTextController", "classapp_1_1view_1_1_output_text_controller.html", "classapp_1_1view_1_1_output_text_controller" ],
      [ "Colors", "enumapp_1_1view_1_1_output_text_controller_1_1_colors.html", "enumapp_1_1view_1_1_output_text_controller_1_1_colors" ]
    ] ]
];