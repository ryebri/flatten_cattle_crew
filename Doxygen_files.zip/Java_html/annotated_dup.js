var annotated_dup =
[
    [ "app", null, [
      [ "model", null, [
        [ "TextOutput", "classapp_1_1model_1_1_text_output.html", "classapp_1_1model_1_1_text_output" ]
      ] ],
      [ "view", null, [
        [ "MainPageController", "classapp_1_1view_1_1_main_page_controller.html", "classapp_1_1view_1_1_main_page_controller" ],
        [ "OutputTextController", "classapp_1_1view_1_1_output_text_controller.html", "classapp_1_1view_1_1_output_text_controller" ]
      ] ],
      [ "Hole", "classapp_1_1_hole.html", "classapp_1_1_hole" ],
      [ "Line", "classapp_1_1_line.html", "classapp_1_1_line" ],
      [ "MainApp", "classapp_1_1_main_app.html", "classapp_1_1_main_app" ],
      [ "Obstruction", "classapp_1_1_obstruction.html", "classapp_1_1_obstruction" ],
      [ "Obstruction_oldstuff", "classapp_1_1_obstruction__oldstuff.html", "classapp_1_1_obstruction__oldstuff" ],
      [ "Pipe", "classapp_1_1_pipe.html", "classapp_1_1_pipe" ],
      [ "Position", "classapp_1_1_position.html", "classapp_1_1_position" ],
      [ "ResizableCanvas", "classapp_1_1_resizable_canvas.html", "classapp_1_1_resizable_canvas" ],
      [ "Rock", "classapp_1_1_rock.html", "classapp_1_1_rock" ],
      [ "RoombaComm", "classapp_1_1_roomba_comm.html", "classapp_1_1_roomba_comm" ],
      [ "SensorData", "classapp_1_1_sensor_data.html", "classapp_1_1_sensor_data" ],
      [ "xboxcontrollerinterface", "classapp_1_1xboxcontrollerinterface.html", "classapp_1_1xboxcontrollerinterface" ]
    ] ]
];