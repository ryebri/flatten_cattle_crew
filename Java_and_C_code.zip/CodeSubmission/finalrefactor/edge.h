/*
 * edge.h
 *
 *  Created on: Nov 15, 2016
 *      Author: borseth
 */

#ifndef EDGE_H_
#define EDGE_H_

void updateedge(botpos_t *b);



#endif /* EDGE_H_ */
