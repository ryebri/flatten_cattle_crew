/**
 * @file MainPageController.java
 * @brief Was intended for use when we were going to have a multi-page program.  Never
 * actually used, but was intended to control a steam roller flattening a cow as we are,
 * "The Flatten Cattle Crew."
 * @author ryebri
 * @date 12/06/2016
 */
package app.view;

import javafx.beans.property.StringProperty;

///Main Page Controller
public class MainPageController {
	private StringProperty commandBox;
	
	public MainPageController() {
		
	}

}
